package uz.alpha.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.Settings
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

class Reply(val text: String, val emotion: Emotion)

/** AI'siz, kalit so'zli o'zbekcha buyruqlar. */
object Commands {

    private val CYR = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo",
        'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m",
        'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
        'ф' to "f", 'х' to "x", 'ц' to "s", 'ч' to "ch", 'ш' to "sh", 'ъ' to "", 'ь' to "",
        'ы' to "i", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o", 'қ' to "q", 'ғ' to "g",
        'ҳ' to "h"
    )

    private val NUM = mapOf(
        "nol" to 0, "bir" to 1, "ikki" to 2, "uch" to 3, "tort" to 4, "besh" to 5,
        "olti" to 6, "yetti" to 7, "sakkiz" to 8, "toqqiz" to 9, "on" to 10,
        "yigirma" to 20, "ottiz" to 30, "qirq" to 40, "ellik" to 50, "oltmish" to 60,
        "yetmish" to 70, "sakson" to 80, "toqson" to 90, "yuz" to 100
    )

    private val SITES = listOf(
        listOf("youtube", "yutub", "you tube") to "https://www.youtube.com",
        listOf("gmail", "jimeyl") to "https://mail.google.com",
        listOf("xarita", "karta", "maps") to "https://maps.google.com",
        listOf("telegram") to "https://t.me",
        listOf("instagram", "insta") to "https://www.instagram.com",
        listOf("google", "gugl") to "https://www.google.com"
    )

    private val MONTHS = listOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )
    private val DAYS = listOf(
        "dushanba", "seshanba", "chorshanba", "payshanba", "juma", "shanba", "yakshanba"
    )

    /** Kichik harf, kirill -> lotin, apostroflarsiz, faqat harf/son/probel. */
    fun normalize(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw.lowercase()) {
            val c = CYR[ch]
            if (c != null) sb.append(c) else sb.append(ch)
        }
        var s = sb.toString()
        for (q in listOf("ʻ", "ʼ", "’", "‘", "`", "´", "'")) {
            s = s.replace(q, "")
        }
        s = s.replace(Regex("[^a-z0-9 ]"), " ")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun parseNumber(w: List<String>): Int? {
        var total = 0
        var found = false
        for (x in w) {
            val m = Regex("^\\d+").find(x)
            if (m != null) return m.value.toIntOrNull()
            val v = NUM[x]
            if (v != null) {
                found = true
                total = if (x == "yuz") (if (total == 0) 100 else total * 100) else total + v
            }
        }
        return if (found) total else null
    }

    /** Buyruq topilsa javob qaytaradi, topilmasa null. */
    fun run(ctx: Context, raw: String): Reply? {
        return try {
            dispatch(ctx, raw)
        } catch (e: Exception) {
            Reply("Bajara olmadim (${e.javaClass.simpleName}).", Emotion.SAD)
        }
    }

    private fun dispatch(ctx: Context, raw: String): Reply? {
        val t = normalize(raw)
        if (t.isEmpty()) return null
        val w = t.split(" ")
        fun has(vararg k: String): Boolean = k.any { t.contains(it) }

        if (w.contains("yordam")) {
            return Reply(
                "Men chiroq, ovoz, batareya, Wi-Fi, soat, sana, taymer, sayt ochish, " +
                    "qidirish va titratishni bilaman.",
                Emotion.HAPPY
            )
        }
        if (has("eslat", "taymer", "timer")) return timer(ctx, w)
        if (has("chiroq", "fonar", "flesh")) return torch(ctx, t)
        if (has("ovoz", "gromkost")) return volume(ctx, t, w)
        if (has("batareya", "zaryad", "quvvat")) return battery(ctx)
        if (has("wifi", "wi fi", "vayfay", "vay fay")) return wifi(ctx, t)
        if (has("titra")) return vibrate(ctx)
        if (has("qidir", "izla")) return search(ctx, w)
        for ((keys, url) in SITES) {
            if (keys.any { t.contains(it) }) return open(ctx, url, "Ochyapman.")
        }
        if (has("soat", "vaqt")) {
            val now = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
            return Reply("Soat $now.", Emotion.HAPPY)
        }
        if (has("sana", "bugun", "hafta kuni")) {
            val d = LocalDate.now()
            return Reply(
                "Bugun ${d.dayOfMonth}-${MONTHS[d.monthValue - 1]}, ${DAYS[d.dayOfWeek.value - 1]}.",
                Emotion.HAPPY
            )
        }
        return null
    }

    private fun open(ctx: Context, url: String, say: String): Reply {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return Reply(say, Emotion.HAPPY)
    }

    private fun search(ctx: Context, w: List<String>): Reply {
        val skip = setOf("ni", "da", "dan", "ga", "ber", "bering")
        val q = w.filter {
            !it.startsWith("google") && !it.startsWith("gugl") &&
                !it.startsWith("qidir") && !it.startsWith("izla") && it !in skip
        }.joinToString(" ")
        if (q.isEmpty()) return Reply("Nimani qidiray?", Emotion.CONFUSED)
        return open(ctx, "https://www.google.com/search?q=" + Uri.encode(q), "Qidiryapman: $q")
    }

    private fun timer(ctx: Context, w: List<String>): Reply {
        val k = w.indexOfFirst { it.startsWith("keyin") }
        val head = if (k >= 0) w.subList(0, k) else w
        val n = parseNumber(head)
            ?: return Reply(
                "Necha daqiqadan keyin? Masalan: 10 daqiqadan keyin choyni eslat.",
                Emotion.CONFUSED
            )
        val secs = when {
            head.any { it.startsWith("soat") } -> n * 3600
            head.any { it.startsWith("soniya") || it.startsWith("sekund") } -> n
            else -> n * 60
        }.coerceIn(1, 86400)
        val e = w.indexOfFirst { it.startsWith("eslat") }
        val words = if (k >= 0 && e > k) w.subList(k + 1, e) else emptyList()
        val msg = if (words.isEmpty()) "Alpha eslatmasi" else words.joinToString(" ")
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, msg)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        val mins = secs / 60
        val human = if (mins >= 1) "$mins daqiqadan" else "$secs soniyadan"
        return Reply("Taymer qo'ydim: $human keyin.", Emotion.HAPPY)
    }

    private fun torch(ctx: Context, t: String): Reply {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return Reply("Telefonda chiroq topilmadi.", Emotion.SAD)
        val off = t.contains("ochir") || t.contains("yop")
        cm.setTorchMode(id, !off)
        return Reply(if (off) "Chiroq o'chdi." else "Chiroq yondi.", Emotion.HAPPY)
    }

    private fun volume(ctx: Context, t: String, w: List<String>): Reply {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val n = parseNumber(w)
        if (n != null) {
            val lvl = n.coerceIn(0, 15)
            val idx = (lvl * max / 15f).roundToInt()
            am.setStreamVolume(AudioManager.STREAM_MUSIC, idx, AudioManager.FLAG_SHOW_UI)
            return Reply("Ovoz $lvl.", Emotion.HAPPY)
        }
        if (t.contains("kotar") || t.contains("oshir") || t.contains("baland")) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI
            )
            return Reply("Ovozni ko'tardim.", Emotion.HAPPY)
        }
        if (t.contains("pasayt") || t.contains("kamayt") || t.contains("past")) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI
            )
            return Reply("Ovozni pasaytirdim.", Emotion.HAPPY)
        }
        val cur = (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 15f / max).roundToInt()
        return Reply("Ovoz hozir $cur, 15 dan.", Emotion.HAPPY)
    }

    private fun battery(ctx: Context): Reply {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return Reply(
            "Batareya $pct foiz" + (if (charging) ", zaryadlanyapti." else "."),
            Emotion.HAPPY
        )
    }

    private fun wifi(ctx: Context, t: String): Reply {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (t.contains("yoq") || t.contains("ochir")) {
            // Android 10+ ilovaga Wi-Fi'ni o'zgartirishga ruxsat bermaydi, oyna ochiladi.
            val action = if (Build.VERSION.SDK_INT >= 30) {
                Settings.Panel.ACTION_WIFI
            } else {
                Settings.ACTION_WIFI_SETTINGS
            }
            ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return Reply("Wi-Fi oynasini ochdim, o'zingiz bosing.", Emotion.HAPPY)
        }
        return Reply(
            if (wm.isWifiEnabled) "Wi-Fi yoqilgan." else "Wi-Fi o'chirilgan.",
            Emotion.HAPPY
        )
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ctx: Context): Reply {
        val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        return Reply("Titradim.", Emotion.HAPPY)
    }
}
