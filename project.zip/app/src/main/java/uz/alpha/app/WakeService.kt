package uz.alpha.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.AssetManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream

/**
 * Doim eshitadigan xizmat: Vosk (oflayn, o'zbekcha model) "Alpha" so'zini kutadi.
 * So'z eshitilsa mikrofonni bo'shatadi va OverlayService'ni ishga tushiradi.
 */
class WakeService : Service() {

    companion object {
        @Volatile
        var instance: WakeService? = null
        private const val MODEL_VERSION = "uz-0.22-a"
        private const val NOTIF_ID = 3
    }

    private val handler = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var paused = false
    private var stopped = false
    private var triggered = false
    private var lastNotify = 0L
    private var wake: List<String> = listOf("alfa", "alpha")

    private val resumeRunnable = Runnable { startVosk() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            stopped = true
            releaseVosk()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        instance = this
        stopped = false
        loadWords()
        goForeground("Model tayyorlanyapti...")
        if (model != null) startVosk() else loadModelAsync()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopped = true
        instance = null
        handler.removeCallbacksAndMessages(null)
        releaseVosk()
        try {
            model?.close()
        } catch (e: Throwable) {
            // e'tiborsiz
        }
        model = null
        super.onDestroy()
    }

    // ---- Bildirishnoma ----

    private fun buildNotif(text: String): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("alpha", "Alpha", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "alpha")
            .setContentTitle("Alpha")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun goForeground(text: String) {
        try {
            val n = buildNotif(text)
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun notifyText(text: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotif(text))
        } catch (e: Exception) {
            // e'tiborsiz
        }
    }

    // ---- Chaqirish so'zlari ----

    private fun loadWords() {
        val raw = getSharedPreferences("alpha", MODE_PRIVATE).getString("wake", "alfa,alpha") ?: ""
        val list = raw.split(",").map { Commands.normalize(it) }.filter { it.isNotEmpty() }
        wake = if (list.isEmpty()) listOf("alfa", "alpha") else list
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun near(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 4 || b.length < 4) return false
        return lev(a, b) <= 1
    }

    private fun matches(text: String): Boolean {
        val tokens = Commands.normalize(text).split(" ")
        return tokens.any { tok -> wake.any { w -> near(tok, w) } }
    }

    // ---- Model ----

    private fun copyAssetDir(am: AssetManager, src: String, dst: File) {
        val names = am.list(src) ?: emptyArray()
        if (names.isEmpty()) {
            try {
                dst.parentFile?.mkdirs()
                am.open(src).use { input ->
                    FileOutputStream(dst).use { out -> input.copyTo(out) }
                }
            } catch (e: FileNotFoundException) {
                dst.mkdirs()
            }
        } else {
            dst.mkdirs()
            for (n in names) copyAssetDir(am, "$src/$n", File(dst, n))
        }
    }

    private fun loadModelAsync() {
        Thread {
            try {
                val dir = File(filesDir, "model-uz")
                val ok = File(filesDir, "model-uz.ok")
                if (!ok.exists() || ok.readText() != MODEL_VERSION) {
                    dir.deleteRecursively()
                    copyAssetDir(assets, "model-uz", dir)
                    ok.writeText(MODEL_VERSION)
                }
                val m = Model(dir.absolutePath)
                handler.post {
                    if (stopped) {
                        m.close()
                    } else {
                        model = m
                        startVosk()
                    }
                }
            } catch (e: Throwable) {
                handler.post {
                    notifyText("Model xatosi: ${e.javaClass.simpleName} ${e.message ?: ""}")
                }
            }
        }.start()
    }

    // ---- Eshitish ----

    private fun startVosk() {
        val m = model ?: return
        if (stopped) return
        releaseVosk()
        try {
            val r = Recognizer(m, 16000.0f)
            val s = SpeechService(r, 16000.0f)
            speech = s
            paused = false
            triggered = false
            s.startListening(listener)
            notifyText("Eshityapman. \"${wake.first()}\" deng.")
        } catch (e: Throwable) {
            notifyText("Eshitish xatosi: ${e.javaClass.simpleName} ${e.message ?: ""}")
        }
    }

    private fun releaseVosk() {
        val s = speech
        speech = null
        if (s != null) {
            try {
                s.stop()
                s.shutdown()
            } catch (e: Throwable) {
                // e'tiborsiz
            }
        }
    }

    private fun extract(h: String?, key: String): String {
        if (h.isNullOrEmpty()) return ""
        return try {
            JSONObject(h).optString(key, "")
        } catch (e: Exception) {
            ""
        }
    }

    private fun check(text: String) {
        if (triggered || paused || stopped || text.isEmpty()) return
        if (matches(text)) {
            triggered = true
            handler.post { trigger() }
        }
    }

    private fun trigger() {
        if (stopped) return
        releaseVosk()
        paused = true
        notifyText("Chaqirildi!")
        handler.removeCallbacks(resumeRunnable)
        handler.postDelayed(resumeRunnable, 30000) // OverlayService xabar bermasa ham qayta boshlanadi
        startService(Intent(this, OverlayService::class.java).putExtra("wake", true))
    }

    /** OverlayService tugagach chaqiriladi. */
    fun resumeListening() {
        if (stopped || !paused) return
        handler.removeCallbacks(resumeRunnable)
        handler.postDelayed(resumeRunnable, 800)
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            check(extract(hypothesis, "partial"))
        }

        override fun onResult(hypothesis: String?) {
            val t = extract(hypothesis, "text")
            if (t.isNotEmpty()) {
                val now = System.currentTimeMillis()
                if (now - lastNotify > 1500) {
                    lastNotify = now
                    notifyText("Eshitdim: $t")
                }
            }
            check(t)
        }

        override fun onFinalResult(hypothesis: String?) {}

        override fun onError(exception: Exception?) {
            notifyText("Xato: ${exception?.message ?: ""}")
        }

        override fun onTimeout() {}
    }
}
