package uz.alpha.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class Form { EYE, ROBOT }

enum class Emotion { WAIT, LISTEN, THINK, HAPPY, EXCITED, SURPRISED, CONFUSED, SAD, SLEEP }

class Palette(
    val dark: Int,
    val screen: Int,
    val main: Int,
    val light: Int,
    val bright: Int,
    val pale: Int,
    val deep: Int
) {
    companion object {
        val BLUE = Palette(
            Color.parseColor("#0B1220"), Color.parseColor("#070B14"),
            Color.parseColor("#4DA3FF"), Color.parseColor("#9CC8FF"),
            Color.parseColor("#CFE4FF"), Color.parseColor("#DBE8FF"),
            Color.parseColor("#2F6FD6")
        )
        val PURPLE = Palette(
            Color.parseColor("#140B24"), Color.parseColor("#0B0714"),
            Color.parseColor("#9B6BFF"), Color.parseColor("#C3A6FF"),
            Color.parseColor("#E6DAFF"), Color.parseColor("#E9E1FF"),
            Color.parseColor("#6B3FD6")
        )
    }
}

/** Alpha personaji: odam ko'zi yoki qo'l-oyoqli robot, 9 ta hissiyot. */
class AlphaView(context: Context) : View(context) {

    var form: Form = Form.ROBOT
        set(value) { field = value; invalidate() }
    var emotion: Emotion = Emotion.WAIT
        set(value) { field = value; invalidate() }
    var palette: Palette = Palette.BLUE
        set(value) { field = value; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val pi = 3.1415927f

    private val ticker = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ticker.start()
    }

    override fun onDetachedFromWindow() {
        ticker.cancel()
        super.onDetachedFromWindow()
    }

    // ---------- yordamchi chizish funksiyalari ----------
    private fun fillC(c: Int) {
        p.style = Paint.Style.FILL
        p.color = c
    }

    private fun strokeC(c: Int, w: Float) {
        p.style = Paint.Style.STROKE
        p.color = c
        p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
    }

    private fun withA(c: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun dot(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
        fillC(col)
        cv.drawCircle(x, y, r, p)
    }

    private fun ring(cv: Canvas, x: Float, y: Float, r: Float, col: Int, w: Float) {
        strokeC(col, w)
        cv.drawCircle(x, y, r, p)
    }

    private fun ln(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, col: Int, w: Float) {
        strokeC(col, w)
        cv.drawLine(x1, y1, x2, y2, p)
    }

    private fun qd(
        cv: Canvas, x1: Float, y1: Float, cx: Float, cy: Float,
        x2: Float, y2: Float, col: Int, w: Float
    ) {
        path.reset()
        path.moveTo(x1, y1)
        path.quadTo(cx, cy, x2, y2)
        strokeC(col, w)
        cv.drawPath(path, p)
    }

    private fun box(
        cv: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float,
        fillColor: Int, lineColor: Int, w: Float
    ) {
        fillC(fillColor)
        cv.drawRoundRect(l, t, r, b, rad, rad, p)
        if (w > 0f) {
            strokeC(lineColor, w)
            cv.drawRoundRect(l, t, r, b, rad, rad, p)
        }
    }

    private fun sparkle(cv: Canvas, x: Float, y: Float, s: Float, col: Int) {
        path.reset()
        path.moveTo(x, y - s)
        path.lineTo(x + s * 0.25f, y - s * 0.25f)
        path.lineTo(x + s, y)
        path.lineTo(x + s * 0.25f, y + s * 0.25f)
        path.lineTo(x, y + s)
        path.lineTo(x - s * 0.25f, y + s * 0.25f)
        path.lineTo(x - s, y)
        path.lineTo(x - s * 0.25f, y - s * 0.25f)
        path.close()
        fillC(col)
        cv.drawPath(path, p)
    }

    /** Pirpirash: 4 soniyada bir marta, 0..1 */
    private fun blink(t: Float): Float {
        val ph = t % 4f
        return if (ph < 0.18f) sin(ph / 0.18f * pi) else 0f
    }

    // ---------- asosiy chizish ----------
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width / 380f, height / 420f)
        val t = (SystemClock.uptimeMillis() % 100000L) / 1000f
        canvas.save()
        canvas.translate((width - 380f * s) / 2f, (height - 420f * s) / 2f)
        canvas.scale(s, s)
        if (form == Form.EYE) drawEye(canvas, t) else drawRobot(canvas, t)
        canvas.restore()
    }

    // ---------- ODAM KO'ZI ----------
    private fun eyeBrow(cv: Canvas, y1: Float, ym: Float, y2: Float) {
        qd(cv, -28f, y1, 0f, ym, 28f, y2, palette.light, 4f)
    }

    private fun drawEye(cv: Canvas, t: Float) {
        val pl = palette
        val e = emotion
        cv.save()
        cv.translate(190f, 215f)
        cv.scale(4.2f, 4.2f)
        cv.translate(0f, sin(t * 2f) * 1.2f)

        when (e) {
            Emotion.HAPPY, Emotion.EXCITED -> {
                qd(cv, -30f, 8f, 0f, -24f, 30f, 8f, pl.main, 5f)
                ln(cv, -18f, -5f, -22f, -10f, pl.main, 2f)
                ln(cv, 0f, -10f, 0f, -17f, pl.main, 2f)
                ln(cv, 18f, -5f, 22f, -10f, pl.main, 2f)
                dot(cv, -26f, 18f, 5f, withA(pl.deep, 140))
                dot(cv, 26f, 18f, 5f, withA(pl.deep, 140))
                eyeBrow(cv, -34f, -44f, -34f)
                sparkle(cv, 38f, -26f, 3f + sin(t * 5f) * 1f, pl.light)
                sparkle(cv, -40f, -18f, 2f + sin(t * 4f + 1f) * 1f, pl.light)
            }
            Emotion.SLEEP -> {
                qd(cv, -30f, -6f, 0f, 16f, 30f, -6f, pl.main, 5f)
                ln(cv, -20f, 3f, -23f, 9f, pl.main, 2f)
                ln(cv, 0f, 7f, 0f, 14f, pl.main, 2f)
                ln(cv, 20f, 3f, 23f, 9f, pl.main, 2f)
                eyeBrow(cv, -28f, -36f, -28f)
                for (i in 0..2) {
                    val ph = (t * 0.5f + i * 0.33f) % 1f
                    dot(cv, 34f + ph * 10f, -10f - ph * 30f, 2f + ph * 3f,
                        withA(pl.light, ((1f - ph) * 220f).toInt()))
                }
            }
            else -> {
                if (e == Emotion.LISTEN) {
                    for (i in 0..1) {
                        val fr = (t * 0.8f + i * 0.5f) % 1f
                        ring(cv, 0f, 0f, 30f + fr * 10f,
                            withA(pl.main, ((1f - fr) * 170f).toInt()), 1.5f)
                    }
                }
                val gx = if (e == Emotion.THINK) 8f else 0f
                val gy = if (e == Emotion.THINK) -5f else 0f
                val lid = blink(t)
                cv.save()
                cv.scale(1f, max(0.06f, 1f - lid))
                path.reset()
                path.moveTo(-34f, 0f)
                path.quadTo(0f, -26f, 34f, 0f)
                path.quadTo(0f, 26f, -34f, 0f)
                path.close()
                fillC(pl.pale)
                cv.drawPath(path, p)
                dot(cv, gx, gy, 12f, pl.main)
                val pr = when (e) {
                    Emotion.SURPRISED -> 3.5f
                    Emotion.EXCITED -> 8f
                    else -> 6f
                }
                dot(cv, gx, gy, pr, pl.dark)
                dot(cv, gx - 4f, gy - 4f, 2.5f, Color.WHITE)
                qd(cv, -34f, 0f, 0f, -26f, 34f, 0f, pl.main, 3f)
                cv.restore()

                ln(cv, -24f, -8f, -28f, -13f, pl.main, 2f)
                ln(cv, -12f, -14f, -14f, -20f, pl.main, 2f)
                ln(cv, 0f, -13f, 0f, -19f, pl.main, 2f)
                ln(cv, 12f, -14f, 14f, -20f, pl.main, 2f)
                ln(cv, 24f, -8f, 28f, -13f, pl.main, 2f)

                when (e) {
                    Emotion.SURPRISED -> eyeBrow(cv, -38f, -50f, -38f)
                    Emotion.CONFUSED -> eyeBrow(cv, -30f, -38f, -42f)
                    Emotion.SAD -> eyeBrow(cv, -24f, -38f, -36f)
                    Emotion.THINK -> eyeBrow(cv, -30f, -40f, -36f)
                    else -> eyeBrow(cv, -30f, -40f, -30f)
                }
                if (e == Emotion.SAD) {
                    val k = (t * 10f) % 12f
                    dot(cv, 24f, 14f + k, 2.5f, withA(pl.light, ((1f - k / 12f) * 220f).toInt()))
                }
            }
        }
        cv.restore()
    }

    // ---------- ROBOT ----------
    private fun eyeDot(cv: Canvas, x: Float, y: Float, r: Float, b: Float) {
        val pl = palette
        cv.save()
        cv.scale(1f, max(0.1f, 1f - b), x, y)
        dot(cv, x, y, r + 5f, withA(pl.main, 70))
        dot(cv, x, y, r, pl.bright)
        cv.restore()
    }

    private fun glowArc(cv: Canvas, cx: Float, cy: Float) {
        val pl = palette
        qd(cv, cx - 15f, cy + 2f, cx, cy - 20f, cx + 15f, cy + 2f, withA(pl.main, 80), 14f)
        qd(cv, cx - 15f, cy + 2f, cx, cy - 20f, cx + 15f, cy + 2f, pl.bright, 6f)
    }

    private fun drawFace(cv: Canvas, t: Float) {
        val pl = palette
        val b = blink(t)
        val lx = 163f
        val rx = 217f
        val y = 122f
        when (emotion) {
            Emotion.WAIT -> {
                eyeDot(cv, lx, y, 9f, b)
                eyeDot(cv, rx, y, 9f, b)
            }
            Emotion.LISTEN -> {
                eyeDot(cv, lx, y, 11f, b)
                eyeDot(cv, rx, y, 11f, b)
            }
            Emotion.THINK -> {
                eyeDot(cv, lx + 6f, y - 6f, 8f, b)
                eyeDot(cv, rx + 6f, y - 6f, 8f, b)
                val n = ((t * 1.5f).toInt()) % 4
                for (i in 0..2) {
                    if (n > i) dot(cv, 170f + i * 14f, 150f, 3f, pl.bright)
                }
            }
            Emotion.HAPPY -> {
                glowArc(cv, lx, y)
                glowArc(cv, rx, y)
            }
            Emotion.EXCITED -> {
                eyeDot(cv, lx, y, 11f, 0f)
                eyeDot(cv, rx, y, 11f, 0f)
                dot(cv, lx - 3f, y - 3f, 2.5f, pl.screen)
                dot(cv, rx - 3f, y - 3f, 2.5f, pl.screen)
                path.reset()
                path.moveTo(176f, 142f)
                path.quadTo(190f, 166f, 204f, 142f)
                path.close()
                fillC(pl.bright)
                cv.drawPath(path, p)
            }
            Emotion.SURPRISED -> {
                ring(cv, lx, y, 11f, pl.bright, 4f)
                ring(cv, rx, y, 11f, pl.bright, 4f)
                ring(cv, 190f, 148f, 6f, pl.bright, 3.5f)
            }
            Emotion.CONFUSED -> {
                eyeDot(cv, lx, y, 8f, b)
                eyeDot(cv, rx, y, 8f, b)
                ln(cv, lx - 12f, y - 18f, lx + 12f, y - 18f, pl.light, 3f)
                ln(cv, rx - 12f, y - 20f, rx + 12f, y - 26f, pl.light, 3f)
                path.reset()
                path.moveTo(176f, 148f)
                path.quadTo(183f, 140f, 190f, 148f)
                path.quadTo(197f, 156f, 204f, 148f)
                strokeC(pl.bright, 3.5f)
                cv.drawPath(path, p)
            }
            Emotion.SAD -> {
                eyeDot(cv, lx, y, 8f, b)
                eyeDot(cv, rx, y, 8f, b)
                ln(cv, lx - 12f, y - 12f, lx + 10f, y - 20f, pl.light, 3f)
                ln(cv, rx - 10f, y - 20f, rx + 12f, y - 12f, pl.light, 3f)
                qd(cv, 178f, 152f, 190f, 140f, 202f, 152f, pl.bright, 3.5f)
                val k = (t * 14f) % 14f
                dot(cv, rx + 14f, y + 22f + k, 3f, withA(pl.light, ((1f - k / 14f) * 230f).toInt()))
            }
            Emotion.SLEEP -> {
                qd(cv, lx - 14f, y - 2f, lx, y + 10f, lx + 14f, y - 2f, pl.bright, 5f)
                qd(cv, rx - 14f, y - 2f, rx, y + 10f, rx + 14f, y - 2f, pl.bright, 5f)
                for (i in 0..2) {
                    val ph = (t * 0.5f + i * 0.33f) % 1f
                    dot(cv, 224f + ph * 16f, 150f - ph * 40f, 2f + ph * 3f,
                        withA(pl.bright, ((1f - ph) * 230f).toInt()))
                }
            }
        }
    }

    private fun drawRobot(cv: Canvas, t: Float) {
        val pl = palette
        val e = emotion
        val fast = e == Emotion.EXCITED

        fillC(withA(pl.dark, 70))
        cv.drawOval(112f, 363f, 268f, 381f, p)

        val bob = if (e == Emotion.SLEEP) 4f
        else sin(t * (if (fast) 6f else 2.2f)) * (if (fast) 7f else 3f)
        cv.save()
        cv.translate(0f, bob)

        // oyoq va krossovka
        box(cv, 152f, 310f, 174f, 346f, 0f, pl.pale, pl.dark, 2.5f)
        box(cv, 206f, 310f, 228f, 346f, 0f, pl.pale, pl.dark, 2.5f)
        box(cv, 140f, 342f, 188f, 366f, 11f, pl.dark, pl.main, 2.5f)
        box(cv, 192f, 342f, 240f, 366f, 11f, pl.dark, pl.main, 2.5f)
        box(cv, 140f, 360f, 188f, 366f, 3f, pl.pale, pl.pale, 0f)
        box(cv, 192f, 360f, 240f, 366f, 3f, pl.pale, pl.pale, 0f)

        // tana (hoodie)
        path.reset()
        path.moveTo(140f, 190f)
        path.cubicTo(130f, 230f, 122f, 270f, 120f, 316f)
        path.lineTo(260f, 316f)
        path.cubicTo(258f, 270f, 250f, 230f, 240f, 190f)
        path.close()
        fillC(pl.dark)
        cv.drawPath(path, p)
        strokeC(pl.main, 3f)
        cv.drawPath(path, p)
        ln(cv, 172f, 200f, 172f, 228f, pl.main, 2f)
        ln(cv, 208f, 200f, 208f, 228f, pl.main, 2f)
        path.reset()
        path.moveTo(178f, 282f)
        path.lineTo(190f, 248f)
        path.lineTo(202f, 282f)
        path.moveTo(183f, 270f)
        path.lineTo(197f, 270f)
        strokeC(pl.main, 3.5f)
        cv.drawPath(path, p)

        // qo'llar
        var lx = 88f
        var ly = 246f
        var lhx = 70f
        var lhy = 252f
        var rx = 292f
        var ry = 266f
        var rhx = 298f
        var rhy = 276f
        var card = false
        when (e) {
            Emotion.WAIT -> card = true
            Emotion.LISTEN -> { lx = 96f; ly = 270f; lhx = 92f; lhy = 282f; rx = 282f; ry = 176f; rhx = 290f; rhy = 164f }
            Emotion.THINK -> { lx = 96f; ly = 270f; lhx = 92f; lhy = 282f; rx = 232f; ry = 206f; rhx = 222f; rhy = 192f }
            Emotion.HAPPY, Emotion.EXCITED -> { lx = 94f; ly = 180f; lhx = 88f; lhy = 168f; rx = 286f; ry = 180f; rhx = 292f; rhy = 168f }
            Emotion.SURPRISED -> { lx = 108f; ly = 178f; lhx = 112f; lhy = 166f; rx = 272f; ry = 178f; rhx = 268f; rhy = 166f }
            Emotion.CONFUSED -> { lx = 84f; ly = 236f; lhx = 68f; lhy = 232f; rx = 296f; ry = 236f; rhx = 312f; rhy = 232f }
            Emotion.SAD, Emotion.SLEEP -> { lx = 122f; ly = 292f; lhx = 120f; lhy = 304f; rx = 258f; ry = 292f; rhx = 260f; rhy = 304f }
        }
        if (fast) {
            val w = sin(t * 9f) * 6f
            ly += w; lhy += w; ry -= w; rhy -= w
        }
        if (card) {
            box(cv, 290f, 190f, 354f, 274f, 8f, pl.dark, pl.main, 3f)
            box(cv, 302f, 202f, 342f, 230f, 9f, Color.TRANSPARENT, pl.light, 2.5f)
            dot(cv, 312f, 216f, 2.5f, pl.light)
            dot(cv, 322f, 216f, 2.5f, pl.light)
            dot(cv, 332f, 216f, 2.5f, pl.light)
            ln(cv, 302f, 248f, 342f, 248f, pl.main, 3f)
            ln(cv, 302f, 258f, 330f, 258f, pl.main, 3f)
        }
        ln(cv, 134f, 222f, lx, ly, pl.main, 30f)
        ln(cv, 134f, 222f, lx, ly, pl.dark, 24f)
        ln(cv, 246f, 222f, rx, ry, pl.main, 30f)
        ln(cv, 246f, 222f, rx, ry, pl.dark, 24f)
        dot(cv, lhx, lhy, 13f, pl.pale)
        ring(cv, lhx, lhy, 13f, pl.dark, 2.5f)
        dot(cv, rhx, rhy, 13f, pl.pale)
        ring(cv, rhx, rhy, 13f, pl.dark, 2.5f)

        // qalpoq
        path.reset()
        path.moveTo(190f, 18f)
        path.cubicTo(130f, 20f, 92f, 70f, 92f, 128f)
        path.cubicTo(92f, 172f, 120f, 196f, 190f, 196f)
        path.cubicTo(260f, 196f, 288f, 172f, 288f, 128f)
        path.cubicTo(288f, 70f, 250f, 20f, 190f, 18f)
        path.close()
        fillC(pl.dark)
        cv.drawPath(path, p)
        strokeC(pl.main, 3f)
        cv.drawPath(path, p)

        // quloqchin
        if (e == Emotion.LISTEN) {
            val g = (t * 2f) % 1f
            ring(cv, 100f, 128f, 28f + g * 8f, withA(pl.main, ((1f - g) * 200f).toInt()), 2f)
            ring(cv, 280f, 128f, 28f + g * 8f, withA(pl.main, ((1f - g) * 200f).toInt()), 2f)
        }
        dot(cv, 100f, 128f, 24f, pl.pale)
        ring(cv, 100f, 128f, 24f, pl.dark, 3f)
        dot(cv, 100f, 128f, 14f, pl.dark)
        ring(cv, 100f, 128f, 14f, pl.main, 2f)
        dot(cv, 280f, 128f, 24f, pl.pale)
        ring(cv, 280f, 128f, 24f, pl.dark, 3f)
        dot(cv, 280f, 128f, 14f, pl.dark)
        ring(cv, 280f, 128f, 14f, pl.main, 2f)

        // yuz va ekran
        box(cv, 116f, 66f, 264f, 174f, 44f, pl.pale, pl.dark, 2.5f)
        box(cv, 126f, 76f, 254f, 164f, 34f, pl.screen, pl.screen, 0f)
        drawFace(cv, t)

        if (e == Emotion.HAPPY || e == Emotion.EXCITED) {
            sparkle(cv, 336f, 150f, 9f + sin(t * 5f) * 2f, pl.light)
            sparkle(cv, 46f, 196f, 9f + sin(t * 4f + 1f) * 2f, pl.light)
            sparkle(cv, 352f, 118f, 5f + sin(t * 6f) * 1.5f, pl.light)
        }
        cv.restore()
    }
}
