package uz.alpha.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/** Alpha'ni boshqa ilovalar ustida ko'rsatadi. Sinov: barcha hissiyotlarni ketma-ket o'tadi. */
class OverlayService : Service() {

    private var view: AlphaView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var idx = 0

    private val steps = listOf(
        Emotion.WAIT, Emotion.LISTEN, Emotion.THINK, Emotion.HAPPY, Emotion.SURPRISED,
        Emotion.CONFUSED, Emotion.SAD, Emotion.EXCITED, Emotion.SLEEP
    )
    private val eyeSet = setOf(Emotion.WAIT, Emotion.LISTEN, Emotion.SURPRISED, Emotion.SLEEP)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        hide()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        show()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hide()
        super.onDestroy()
    }

    private fun show() {
        val prefs = getSharedPreferences("alpha", MODE_PRIVATE)
        val v = AlphaView(this)
        v.palette = if (prefs.getString("color", "blue") == "purple") Palette.PURPLE else Palette.BLUE
        val mode = prefs.getString("form", "auto") ?: "auto"

        val d = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            (300 * d).toInt(),
            (330 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.x = (8 * d).toInt()
        lp.y = (96 * d).toInt()

        v.setOnClickListener {
            hide()
            stopSelf()
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
        view = v
        idx = 0
        step(mode)
    }

    private fun step(mode: String) {
        val v = view ?: return
        if (idx >= steps.size) {
            hide()
            stopSelf()
            return
        }
        val e = steps[idx]
        v.form = when (mode) {
            "eye" -> Form.EYE
            "robot" -> Form.ROBOT
            else -> if (e in eyeSet) Form.EYE else Form.ROBOT
        }
        v.emotion = e
        idx++
        handler.postDelayed({ step(mode) }, 1800L)
    }

    private fun hide() {
        handler.removeCallbacksAndMessages(null)
        val v = view
        if (v != null) {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (e: Exception) {
                // oyna allaqachon olib tashlangan
            }
        }
        view = null
    }
}
