package uz.alpha.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import java.util.Locale

/**
 * Alpha'ni boshqa ilovalar ustida ko'rsatadi.
 * Oddiy ishga tushirish: tinglaydi, buyruqni bajaradi, javob beradi, yo'qoladi.
 * "demo" extra bilan: barcha hissiyotlarni ketma-ket ko'rsatadi.
 */
class OverlayService : Service() {

    private var view: AlphaView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var idx = 0
    private var mode = "auto"
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val steps = listOf(
        Emotion.WAIT, Emotion.LISTEN, Emotion.THINK, Emotion.HAPPY, Emotion.SURPRISED,
        Emotion.CONFUSED, Emotion.SAD, Emotion.EXCITED, Emotion.SLEEP
    )
    private val eyeSet = setOf(Emotion.WAIT, Emotion.LISTEN, Emotion.SURPRISED, Emotion.SLEEP)

    private val closer = Runnable {
        cleanup()
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val demo = intent?.getBooleanExtra("demo", false) == true
        if (!demo) goForeground()
        cleanup()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        show()
        if (demo) {
            idx = 0
            step()
        } else {
            startVoice()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun goForeground() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("alpha", "Alpha", NotificationManager.IMPORTANCE_LOW)
            )
            val n = Notification.Builder(this, "alpha")
                .setContentTitle("Alpha")
                .setContentText("Tinglayapti...")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            toast("Xizmatni ishga tushirib bo'lmadi: ${e.javaClass.simpleName}")
        }
    }

    private fun show() {
        val prefs = getSharedPreferences("alpha", MODE_PRIVATE)
        val v = AlphaView(this)
        v.palette = if (prefs.getString("color", "blue") == "purple") Palette.PURPLE else Palette.BLUE
        mode = prefs.getString("form", "auto") ?: "auto"

        val d = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            (300 * d).toInt(),
            (330 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.END
        lp.x = (8 * d).toInt()
        lp.y = (96 * d).toInt()

        v.setOnClickListener {
            cleanup()
            stopSelf()
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
        view = v
        applyEmotion(Emotion.WAIT)
    }

    private fun applyEmotion(e: Emotion) {
        val v = view ?: return
        v.form = when (mode) {
            "eye" -> Form.EYE
            "robot" -> Form.ROBOT
            else -> if (e in eyeSet) Form.EYE else Form.ROBOT
        }
        v.emotion = e
    }

    // ---- Demo: hissiyotlarni ketma-ket ko'rsatish ----

    private fun step() {
        if (view == null) return
        if (idx >= steps.size) {
            cleanup()
            stopSelf()
            return
        }
        applyEmotion(steps[idx])
        idx++
        handler.postDelayed({ step() }, 1800L)
    }

    // ---- Ovoz: eshitish, buyruq, javob ----

    private fun startVoice() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) prepareTts()
        }
        listen()
    }

    private fun prepareTts() {
        val t = tts ?: return
        var r = t.setLanguage(Locale("uz", "UZ"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            // O'zbek ovozi yo'q bo'lsa, turk tili lotin imlosiga yaqinroq.
            r = t.setLanguage(Locale("tr", "TR"))
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                handler.post { closeLater(1200) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handler.post { closeLater(1200) }
            }
        })
        ttsReady = true
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            finishWith("Nutq tanish xizmati topilmadi.", Emotion.SAD)
            return
        }
        applyEmotion(Emotion.LISTEN)
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                applyEmotion(Emotion.THINK)
            }

            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        finishWith("Eshitmadim. Yana urinib ko'ring.", Emotion.CONFUSED)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        finishWith("Mikrofon ruxsati yo'q.", Emotion.SAD)
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        finishWith("Internet kerak.", Emotion.SAD)
                    else -> finishWith("Tanib bo'lmadi, xato kodi $error.", Emotion.SAD)
                }
            }

            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                handleSpeech(list ?: arrayListOf())
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        r.startListening(i)
    }

    private fun handleSpeech(list: List<String>) {
        applyEmotion(Emotion.THINK)
        val heard = list.firstOrNull() ?: ""
        if (heard.isNotEmpty()) toast("Eshitdim: $heard")
        var reply: Reply? = null
        for (s in list) {
            reply = Commands.run(this, s)
            if (reply != null) break
        }
        if (reply == null) {
            reply = Reply("Tushunmadim. Yordam deb ayting.", Emotion.CONFUSED)
        }
        finishWith(reply.text, reply.emotion)
    }

    private fun finishWith(text: String, emotion: Emotion) {
        applyEmotion(emotion)
        toast(text)
        val t = tts
        if (t != null && ttsReady) {
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alpha")
            closeLater(12000) // onDone kelmasa ham yopiladi
        } else {
            closeLater(3500)
        }
    }

    private fun closeLater(ms: Long) {
        handler.removeCallbacks(closer)
        handler.postDelayed(closer, ms)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // e'tiborsiz
        }
        recognizer = null
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            // e'tiborsiz
        }
        tts = null
        ttsReady = false
        val v = view
        if (v != null) {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (e: Exception) {
                // oyna allaqachon olib tashlangan
            }
        }
        view = null
    }
}
