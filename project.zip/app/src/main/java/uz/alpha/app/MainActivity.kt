package uz.alpha.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun micOk(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askMic() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 7)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int): Int = (v * d).toInt()
        val prefs = getSharedPreferences("alpha", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0A0E13"))
        root.setPadding(px(20), px(48), px(20), px(32))

        fun label(s: String, size: Float, color: String, top: Int): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            t.setTextColor(Color.parseColor(color))
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = px(top)
            root.addView(t, lp)
            return t
        }

        fun button(s: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = s
            b.isAllCaps = false
            b.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = px(8)
            root.addView(b, lp)
        }

        fun toast(s: String) {
            Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        }

        label("Alpha", 30f, "#FFFFFF", 0)
        status = label("", 15f, "#9CC8FF", 4)

        button("1. Ruxsat: boshqa ilovalar ustida ko'rsatish") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Ruxsat: mikrofon va bildirishnoma") {
            askMic()
        }
        button("3. Alpha'ni chaqirish (gapiring)") {
            if (!Settings.canDrawOverlays(this)) {
                toast("Avval 1-tugma bilan ruxsat bering")
            } else if (!micOk()) {
                toast("Avval 2-tugma bilan ruxsat bering")
                askMic()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
                moveTaskToBack(true)
            }
        }
        button("Hissiyotlarni sinash (ovozsiz)") {
            if (!Settings.canDrawOverlays(this)) {
                toast("Avval 1-tugma bilan ruxsat bering")
            } else {
                startService(Intent(this, OverlayService::class.java).putExtra("demo", true))
                moveTaskToBack(true)
            }
        }

        label("\"Alpha\" deb chaqirish (doim eshitish)", 16f, "#FFFFFF", 24)
        button("4. Doim eshitishni yoqish") {
            if (!Settings.canDrawOverlays(this)) {
                toast("Avval 1-tugma bilan ruxsat bering")
            } else if (!micOk()) {
                toast("Avval 2-tugma bilan ruxsat bering")
                askMic()
            } else {
                startForegroundService(Intent(this, WakeService::class.java))
                toast("Model tayyorlanyapti. Bildirishnomani kuzating.")
            }
        }
        button("Doim eshitishni to'xtatish") {
            startService(Intent(this, WakeService::class.java).setAction("stop"))
            toast("To'xtatildi")
        }
        label("Chaqirish so'zlari (vergul bilan):", 14f, "#9CC8FF", 12)
        val wakeBox = EditText(this)
        wakeBox.setText(prefs.getString("wake", "alfa,alpha"))
        wakeBox.setTextColor(Color.WHITE)
        wakeBox.setSingleLine(true)
        root.addView(
            wakeBox,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        button("Chaqirish so'zlarini saqlash") {
            prefs.edit().putString("wake", wakeBox.text.toString()).apply()
            toast("Saqlandi. Doim eshitishni qayta yoqing.")
        }

        label("Rang", 16f, "#FFFFFF", 24)
        button("Ko'k") {
            prefs.edit().putString("color", "blue").apply()
            toast("Rang: ko'k")
        }
        button("Binafsha") {
            prefs.edit().putString("color", "purple").apply()
            toast("Rang: binafsha")
        }

        label("Shakl", 16f, "#FFFFFF", 24)
        button("Faqat ko'z") {
            prefs.edit().putString("form", "eye").apply()
            toast("Shakl: ko'z")
        }
        button("Faqat robot") {
            prefs.edit().putString("form", "robot").apply()
            toast("Shakl: robot")
        }
        button("O'zi tanlasin") {
            prefs.edit().putString("form", "auto").apply()
            toast("Shakl: o'zi tanlaydi")
        }

        label("Ekrandagi Alpha'ni yopish: ustiga bosing.", 14f, "#7D8A99", 24)
        label(
            "Buyruqlar: yordam, chiroqni yoq/o'chir, ovozni 8 ga qo'y, batareya, " +
                "soat nechi, 10 daqiqadan keyin choyni eslat, youtube och, google'da ... qidir",
            13f, "#7D8A99", 8
        )

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val ov = if (Settings.canDrawOverlays(this)) "bor" else "yo'q (1-tugma)"
        val mic = if (micOk()) "bor" else "yo'q (2-tugma)"
        status.text = "Ustida ko'rsatish: $ov\nMikrofon: $mic"
    }
}
